//
//  ViewController.m
//  SAQQTablePull
//
//  Created by Andy on 15/7/17.
//  Copyright (c) 2015年 Andy. All rights reserved.
//

#import "ViewController.h"
#import "SAQQTablePullView.h"

@interface ViewController ()

@property (nonatomic, strong) SAQQTablePullView *pullTableview;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    [self prepareTableView];
}

- (void)prepareTableView {
    
    
}

@end
