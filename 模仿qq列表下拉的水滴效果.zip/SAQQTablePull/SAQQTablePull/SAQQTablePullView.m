//
//  SAQQTablePullView.m
//  SAQQTablePull
//
//  Created by Andy on 15/7/17.
//  Copyright (c) 2015年 Andy. All rights reserved.
//

#import "SAQQTablePullView.h"

#define kCircleRadius   30

@interface SAQQTablePullView() <UITableViewDelegate,UIScrollViewDelegate> {
    
    CGSize screenSize;
}

@property (nonatomic, strong) CAShapeLayer      *circleLayer;
@property (nonatomic, strong) UITableView       *tableview;
@property (nonatomic, strong) UIActivityIndicatorView *indicatorView;
@property (nonatomic, weak)   id                 tableviewDelegate;

@end

@implementation SAQQTablePullView

-(instancetype)initWithFrame:(CGRect)frame tableviewDelegate:(id)delegate {
    
    self = [super initWithFrame:frame];
    if (self) {
        // 
        self.tableviewDelegate = delegate;
        screenSize = self.bounds.size;
        [self prepareSubviews];
    }
    return self;
}


- (void)prepareSubviews {
    
    // tableview
    self.tableview = [[UITableView alloc] initWithFrame:CGRectMake(0, kCircleRadius, screenSize.width, screenSize.height - 44 - kCircleRadius) style:UITableViewStylePlain];
    _tableview.delegate = self;
    _tableview.dataSource = _tableviewDelegate;
    [self addSubview:_tableview];
    // circleLayer
    _circleLayer = [CAShapeLayer layer];
    _circleLayer.fillColor = [UIColor lightGrayColor].CGColor;
    
    UIBezierPath *oriPath = [UIBezierPath bezierPath];
    [oriPath moveToPoint:CGPointMake((screenSize.width - kCircleRadius)/2, kCircleRadius/2)];
    [oriPath addArcWithCenter:CGPointMake(screenSize.width/2, kCircleRadius/2) radius:kCircleRadius/2 startAngle:0.000001 endAngle:0 clockwise:YES];
    _circleLayer.path = oriPath.CGPath;
    
    [self.layer addSublayer:_circleLayer];
    
    
    _indicatorView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    _indicatorView.center = CGPointMake(screenSize.width/2, kCircleRadius/2);
    //[_indicatorView startAnimating];
    [self addSubview:_indicatorView];
    
}


#pragma mark --UITableview delegate
-(void)scrollViewDidScroll:(UIScrollView *)scrollView {
    

    // 大圆半径倍率 y = -0.01x + 1
    // 小圆半径倍率 y = -0.014x + 1
    if (scrollView.contentOffset.y > 0) {
        return;
    }
    
    CGFloat offset = fabs(scrollView.contentOffset.y);
    if (offset > 50) {
        _circleLayer.hidden = YES;
        [_indicatorView startAnimating];
    }
    CGFloat bigCircleWidth = (-0.006 * offset + 1) * kCircleRadius;
    CGFloat smallCircleWidth = (-0.015 * offset + 1) * kCircleRadius;
    CGPoint pointA = CGPointMake((screenSize.width - bigCircleWidth)/2, bigCircleWidth /2);
    CGPoint pointB = CGPointMake((screenSize.width + bigCircleWidth)/2, bigCircleWidth /2);
    CGPoint centerAB = CGPointMake((screenSize.width)/2, bigCircleWidth /2);
    CGPoint pointC = CGPointMake((screenSize.width + smallCircleWidth)/2, bigCircleWidth /2 + offset);
    CGPoint pointD = CGPointMake((screenSize.width - smallCircleWidth)/2, bigCircleWidth /2 + offset);
    CGPoint centerCD = CGPointMake((screenSize.width)/2, bigCircleWidth /2 + offset);
    CGPoint centerBC = CGPointMake((pointB.x + pointC.x)/2 - offset * 0.05, (pointB.y + pointC.y)/2);
    CGPoint centerAD = CGPointMake((pointA.x + pointD.x)/2 + offset * 0.05, (pointA.y + pointD.y)/2);
    
    UIBezierPath *circliePath = [UIBezierPath bezierPath];
    [circliePath moveToPoint:pointA];
    [circliePath addArcWithCenter:centerAB radius:bigCircleWidth/2 startAngle:M_PI endAngle:0 clockwise:YES];
    //[circliePath addLineToPoint:pointC];
    [circliePath addCurveToPoint:pointC controlPoint1:pointB controlPoint2:centerBC];
    [circliePath addArcWithCenter:centerCD radius:smallCircleWidth/2 startAngle:0 endAngle:M_PI clockwise:YES];
    //[circliePath addLineToPoint:pointA];
    [circliePath addCurveToPoint:pointA controlPoint1:pointD controlPoint2:centerAD];
    _circleLayer.path = circliePath.CGPath;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [_indicatorView stopAnimating];
    _circleLayer.hidden = NO;
}


@end
