//
//  SAQQTablePullView.h
//  SAQQTablePull
//
//  Created by Andy on 15/7/17.
//  Copyright (c) 2015年 Andy. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol QQPullTableviewDelegate <NSObject>

@required


@end

@interface SAQQTablePullView : UIView

/**
 *  初始化
 *
 *  @param frame    frame
 *  @param delegate talbeview的delegate
 *
 *  @return view
 */
-(instancetype)initWithFrame:(CGRect)frame tableviewDelegate:(id)delegate;

@end
