//
//  SAViewCOntroller.m
//  SAQQTablePull
//
//  Created by Andy on 15/7/20.
//  Copyright (c) 2015年 Andy. All rights reserved.
//

#import "SAViewCOntroller.h"
#import "SAQQTablePullView.h"

#define kTableviewIdentifier    @"QQTableViewCellIdentifier"

@interface SAViewCOntroller () <UITableViewDataSource>

@property (nonatomic, strong) SAQQTablePullView *qqTableview;

@end

@implementation SAViewCOntroller

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 调整navigationController的起始坐标
    //self.navigationController.navigationBar.translucent = NO;
    self.edgesForExtendedLayout = UIRectEdgeNone;
    self.view.backgroundColor = [UIColor whiteColor];
    
    self.qqTableview = [[SAQQTablePullView alloc] initWithFrame:self.view.bounds tableviewDelegate:self];
    [self.view addSubview:_qqTableview];

}



#pragma mark tableview --datasource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return 100;
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:kTableviewIdentifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:kTableviewIdentifier];
    }
    cell.textLabel.text = [NSString stringWithFormat:@"%ld",(long)indexPath.row];
    
    return cell;
    
}


@end
